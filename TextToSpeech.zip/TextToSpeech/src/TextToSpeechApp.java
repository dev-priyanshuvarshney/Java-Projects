import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TextToSpeechApp extends JFrame implements ActionListener {
    JTextArea textArea;
    JFrame frame;
    private Voice maleVoice, femaleVoice;
    JButton maleButton, femaleButton, stopButton;

    private void createGUI() {
        frame = new JFrame("Text-To-Speech");
        frame.setSize(600, 500);
        frame.setLocation(400, 50);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout(10,10));
        frame.setVisible(true);

        textArea = new JTextArea();
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setFont(new Font("Arial", Font.BOLD, 26));

        JScrollPane scrollPane = new JScrollPane(textArea);
        frame.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));

        ImageIcon mIcon = new ImageIcon(ClassLoader.getSystemResource("icons/man.png"));
        Image mImg = mIcon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
        JLabel maleIconLabel = new JLabel(new ImageIcon(mImg));
        maleButton = new JButton("Male Voice");
        maleButton.addActionListener(e -> speak(maleVoice));
        buttonPanel.add(maleIconLabel);
        buttonPanel.add(maleButton);

        ImageIcon fIcon = new ImageIcon(ClassLoader.getSystemResource("icons/woman-avatar.png"));
        Image fImg = fIcon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
        JLabel femaleIconLabel = new JLabel(new ImageIcon(fImg));
        femaleButton = new JButton("Female Voice");
        femaleButton.addActionListener(e -> speak(femaleVoice));
        buttonPanel.add(femaleIconLabel);
        buttonPanel.add(femaleButton);

        ImageIcon sIcon = new ImageIcon(ClassLoader.getSystemResource("icons/stop-button.png"));
        Image sImg = sIcon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
        JLabel stopIconLabel = new JLabel(new ImageIcon(sImg));
        stopButton = new JButton("Stop");
        stopButton.addActionListener(this);
        buttonPanel.add(stopIconLabel);
        buttonPanel.add(stopButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);
        frame.setVisible(true);

        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                cleanupResources();
            }
        });
    }

    private void initVoices() {
        System.setProperty("freetts.voices", "com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory,"
                        + "com.sun.speech.freetts.en.us.cmu_time_awb.AlanVoiceDirectory");

        VoiceManager vm = VoiceManager.getInstance();
        maleVoice = vm.getVoice("kevin16");
        femaleVoice = vm.getVoice("kevin16");

        if (maleVoice == null || femaleVoice == null) {
            JOptionPane.showMessageDialog(null, "❌ Voice not found. Check if JARs are added properly.");
            System.exit(1);
        }
        maleVoice.allocate();
        femaleVoice.allocate();
        femaleVoice.setPitch(75);
        femaleVoice.setPitchRange(4);
        femaleVoice.setRate(150);
    }

    private void speak(Voice voice) {
        String text = textArea.getText();
        if (text.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please Enter Text First!");
            return;
        }
        try {
            voice.speak(text);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Error Speaking Text!");
        }
    }

    private void cleanupResources() {
        if (frame != null) {
            frame.dispose();
            frame = null;
        }
        if (maleVoice != null) {
            maleVoice.deallocate();
            maleVoice = null;
        }
        if (femaleVoice != null) {
            femaleVoice.deallocate();
            femaleVoice = null;
        }

        for (Window window : Window.getWindows()) {
            if (window.isShowing()) {
                window.dispose();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TextToSpeechApp app = new TextToSpeechApp();
            app.initVoices();
            app.createGUI();
        });
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource()==stopButton){
            System.exit(0);
        }
    }
}

