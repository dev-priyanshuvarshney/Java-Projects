import javax.speech.Central;
import javax.speech.synthesis.Synthesizer;
import javax.speech.synthesis.SynthesizerModeDesc;
import java.util.Locale;

public class VoiceTest {
    public static void main(String[] args) throws Exception {
        System.setProperty("freetts.voices",
                "com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory");

        SynthesizerModeDesc desc = new SynthesizerModeDesc(null, "general", Locale.US, null, null);
        Synthesizer synth = Central.createSynthesizer(desc);

        System.out.println("Synthesizer: " + synth);

        if (synth == null) {
            System.out.println("❌ Synthesizer not found. Voice loading failed.");
            return;
        }

        synth.allocate();
        synth.resume();
        synth.speakPlainText("Hello Bhai, ab chal gaya!", null);
        synth.waitEngineState(Synthesizer.QUEUE_EMPTY);
        synth.deallocate();
    }
}