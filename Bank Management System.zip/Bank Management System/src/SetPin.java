import javax.swing.*;

public class SetPin extends JFrame {
    SetPin(){
        setSize(500,500);
        setLocation(400,50);
        setLayout(null);
        setVisible(true);
        JLabel text = new JLabel("OTP was Successfully sent on");
    }
    public static void main(String[] args) {
        new SetPin();
    }
}
