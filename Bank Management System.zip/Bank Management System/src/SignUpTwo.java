import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

public class SignUpTwo extends JFrame implements ActionListener{

    JComboBox religionBox, categoryBox, incomeBox;
    JTextField qualification, occupationbox, panNo, aadharno;
    JRadioButton yes, no, yesa, noa;
    String formNo;
    SignUpTwo(String formNo){
        this.formNo = formNo;
        setVisible(true);
        setLayout(null);
        setLocation(350,15);
        setSize(800,800);
        setTitle("SIGN-UP FORM");
        getContentPane().setBackground(Color.white);

        JLabel text = new JLabel("Page No.-2");
        text.setFont(new Font("Raleway", Font.BOLD, 38));
        text.setBounds(300,50,600,50);
        add(text);

        JLabel religion = new JLabel("Religion");
        religion.setFont(new Font("Arial", Font.BOLD, 28));
        religion.setBounds(80,150,400,50);
        add(religion);

        String valReligion[] = {"Null","Hindu", "Muslim", "Sikh", "Christian"};
        religionBox = new JComboBox(valReligion);
        religionBox.setFont(new Font("Arial", Font.PLAIN, 20));
        religionBox.setBounds(350,160,150,40);
        religionBox.setBackground(Color.WHITE);
        add(religionBox);

        JLabel category = new JLabel("Category");
        category.setBounds(80,210,400,50);
        category.setFont(new Font("Arial", Font.BOLD, 28));
        add(category);
        String valCategory[] = {"Null","UR", "SC", "ST", "OBC", "Other"};
        categoryBox = new JComboBox(valCategory);
        categoryBox.setBounds(350,220,150,40);
        categoryBox.setFont(new Font("Arial",Font.PLAIN,20));
        categoryBox.setBackground(Color.WHITE);
        add(categoryBox);

        JLabel income = new JLabel("Income");
        income.setBounds(80,270,400,50);
        income.setFont(new Font("Arial", Font.BOLD, 28));
        add(income);

        String valIncome[] = {"NA", "Below<10000", "10000-20000", "20000-50000", "Above>50000"};
        incomeBox = new JComboBox(valIncome);
        incomeBox.setBounds(350,280,150,40);
        incomeBox.setFont(new Font("Arial",Font.PLAIN, 20));
        incomeBox.setBackground(Color.WHITE);
        add(incomeBox);

        JLabel e = new JLabel("Educational");
        e.setBounds(80,330,400,50);
        e.setFont(new Font("Arial", Font.BOLD, 28));
        add(e);

        JLabel q = new JLabel("Qualification");
        q.setBounds(80,360,400,50);
        q.setFont(new Font("Arial", Font.BOLD, 28));
        add(q);
        qualification = new JTextField("Enter Your Highest Qualification:");
        qualification.setBounds(350,360,400,50);
        qualification.setFont(new Font("Arial", Font.PLAIN, 20));
        qualification.addActionListener(this);
        add(qualification);

        qualification.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if(qualification.getText().equals("Enter Your Highest Qualification:")){
                    qualification.setText("");
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if(qualification.getText().isEmpty()){
                    qualification.setText("Enter Your Highest Qualification:");
                }
            }
        });
        JLabel occupation = new JLabel("Occupation");
        occupation.setBounds(80,420,400,50);
        occupation.setFont(new Font("Arial", Font.BOLD, 28));
        add(occupation);
        occupationbox = new JTextField("Enter Your Occupation:");
        occupationbox.setBounds(350,420,400,50);
        occupationbox.setFont(new Font("Arial", Font.PLAIN, 20));
        add(occupationbox);

        occupationbox.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if(occupationbox.getText().equals("Enter Your Occupation:")){
                    occupationbox.setText("");
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if(occupationbox.getText().isEmpty()){
                    occupationbox.setText("Enter Your Occupation:");
                }
            }
        });

        JLabel pan = new JLabel("PAN Number");
        pan.setBounds(80,480,400,50);
        pan.setFont(new Font("Arial", Font.BOLD, 28));
        add(pan);
        panNo = new JTextField("Enter Your PAN Number:");
        panNo.setBounds(350,480,400,50);
        panNo.setFont(new Font("Arial", Font.PLAIN, 20));
        add(panNo);

        panNo.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if(panNo.getText().equals("Enter Your PAN Number:")){
                    panNo.setText("");
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if(panNo.getText().isEmpty()){
                    panNo.setText("Enter Your PAN Number:");
                }
            }
        });

        JLabel aadhar = new JLabel("Aadhar No.");
        aadhar.setBounds(80,540,400,50);
        aadhar.setFont(new Font("Arial", Font.BOLD, 28));
        add(aadhar);
        aadharno = new JTextField("Enter Your Aadhar Number:");
        aadharno.setBounds(350,540,400,50);
        aadharno.setFont(new Font("Arial", Font.PLAIN, 20));
        add(aadharno);

        aadharno.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if(aadharno.getText().equals("Enter Your Aadhar Number:")){
                    aadharno.setText("");
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if(aadharno.getText().isEmpty()){
                    aadharno.setText("Enter Your Aadhar Number:");
                }
            }
        });

        JLabel Sc = new JLabel("Senior Citizens");
        Sc.setBounds(80,600,400,50);
        Sc.setFont(new Font("Arial", Font.BOLD, 28));
        add(Sc);
        yes = new JRadioButton("YES");
        yes.setBounds(350,610,100,30);
        yes.setFont(new Font("Arial", Font.PLAIN, 20));
        yes.setBackground(Color.white);
        yes.setForeground(Color.black);
        add(yes);
        no = new JRadioButton("NO");
        no.setBounds(500,610,100,30);
        no.setFont(new Font("Arial", Font.PLAIN, 20));
        no.setBackground(Color.WHITE);
        no.setForeground(Color.BLACK);
        add(no);
        ButtonGroup scgroup = new ButtonGroup();
        scgroup.add(yes);
        scgroup.add(no);

        JLabel acc = new JLabel("Existing Account");
        acc.setBounds(80,660,400,50);
        acc.setFont(new Font("Arial", Font.BOLD, 28));
        add(acc);
        yesa = new JRadioButton("YES");
        yesa.setBounds(350,670,100,30);
        yesa.setFont(new Font("Arial", Font.PLAIN, 20));
        yesa.setBackground(Color.white);
        yesa.setForeground(Color.black);
        add(yesa);

        noa = new JRadioButton("NO");
        noa.setBounds(500,670,100,30);
        noa.setFont(new Font("Arial", Font.PLAIN, 20));
        noa.setBackground(Color.WHITE);
        noa.setForeground(Color.BLACK);
        add(noa);
        ButtonGroup ea = new ButtonGroup();
        ea.add(yesa);
        ea.add(noa);

        JButton nextButton = new JButton("Next");
        nextButton.setForeground(Color.white);
        nextButton.setBackground(Color.black);
        nextButton.setFont(new Font("Arial", Font.BOLD, 28));
        nextButton.setBounds(600,740,200,30);
        add(nextButton);
        nextButton.addActionListener(this);
    }

    public void actionPerformed(ActionEvent ae){
        String religions = religionBox.getSelectedItem().toString();
        String categorys = categoryBox.getSelectedItem().toString();
        String incomes = incomeBox.getSelectedItem().toString();
        String qualifications = qualification.getText();
        String occupations = occupationbox.getText();
        String pans = panNo.getText();
        String aadhars = aadharno.getText();
        String sc = null;
        if(yes.isSelected()){
            sc = "YES";
        }
        else if(no.isSelected()){
            sc = "NO";
        }
        String existingaccount = null;
        if(yesa.isSelected()){
            existingaccount = "YES";
        }
        else if(noa.isSelected()){
            existingaccount = "NO";
        }
        if(ae.getSource()==qualifications){
            qualification.setText(null);
        }
        try{
            Conn c = new Conn();
            String query = "insert into signupTwo values('"+formNo+"', '"+religions+"', '"+categorys+"', '"+incomes+"', '"+qualifications+"', '"+occupations+"', '"+pans+"', '"+aadhars+"', '"+sc+"', '"+existingaccount+"')";
            c.s.executeUpdate(query);
            setVisible(false);
            new SignUpThree(formNo).setVisible(true);
        }
        catch (Exception e){
            System.out.println(e);
        }
    }
    public static void main(String[] args) {
        new SignUpTwo("");
    }
}
