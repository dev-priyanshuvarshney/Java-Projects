import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

public class Deposit extends JFrame implements ActionListener {
    JLabel text;
    JTextField textbox;
    JButton deposit,back;
    String pinnum;
    Deposit(String pinnum){
        this.pinnum = pinnum;
        setLayout(null);
        setSize(700,700);
        setLocation(350,20);
        setVisible(true);
        getContentPane().setBackground(Color.white);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(700,700,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0,700,700);
        add(image);

        text = new JLabel("Enter the Amount you want to deposit");
        text.setBounds(140,230,400,30);
        text.setFont(new Font("Raleway",Font.BOLD,12));
        text.setForeground(Color.white);
        image.add(text);
        textbox = new JTextField();
        textbox.setBounds(140,260,150,20);
        textbox.setFont(new Font("Arial",Font.BOLD,10));
        textbox.addActionListener(this);
        image.add(textbox);

        deposit = new JButton("Deposit");
        deposit.setBounds(275,390,120,30);
        deposit.setBackground(Color.white);
        deposit.setForeground(Color.black);
        deposit.setFont(new Font("Raleway",Font.BOLD,18));
        deposit.addActionListener(this);
        image.add(deposit);

        back = new JButton("Back");
        back.setBounds(140,390,120,30);
        back.setBackground(Color.white);
        back.setForeground(Color.black);
        back.setFont(new Font("Raleway",Font.BOLD,18));
        back.addActionListener(this);
        image.add(back);

    }
    public void actionPerformed(ActionEvent ae){
        String amount = textbox.getText();
        Date date = new Date();
        if(ae.getSource()==deposit) {
            if (amount.equals("")) {
                JOptionPane.showMessageDialog(null, "Please enter the Amount");
            } else {
                try {
                    Conn conn = new Conn();
                    String query = "insert into bank values('" + pinnum + "', '" + date + "','Deposit','" + amount + "')";
                    conn.s.executeUpdate(query);
                    JOptionPane.showMessageDialog(null, "Rs " + amount + " will be added to Your Account");
                    textbox.setText("");
                    setVisible(false);
                    new Transactions(pinnum).setVisible(true);
                }
                catch (Exception e){
                    System.out.println(e);
                }
            }
        }
        else if(ae.getSource() == back){
            setVisible(false);
            new Transactions(pinnum).setVisible(true);
        }
    }
    public static void main(String[] args) {
        new Deposit("");
    }
}
