import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class ChangePin extends JFrame implements ActionListener {
    JLabel text,pinnumtext,newpinnum;
    JPasswordField cardnumbox,pinnumbox,newpinnumbox;
    JButton clear, setpin;
    String pinnum;
    ChangePin(String pinnum){
        this.pinnum=pinnum;
        setSize(700,700);
        setLocation(350,50);
        setVisible(true);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(700,700,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0,700,700);
        add(image);

        text = new JLabel("Change your PIN");
        text.setBounds(180,220,250,30);
        text.setFont(new Font("Californian FB",Font.BOLD,20));
        text.setForeground(Color.white);
        image.add(text);
        pinnumtext = new JLabel("Old PIN:-");
        pinnumtext.setBounds(130,315,100,20);
        pinnumtext.setFont(new Font("Raleway",Font.BOLD,16));
        pinnumtext.setForeground(Color.white);
        image.add(pinnumtext);
        pinnumbox = new JPasswordField("");
        pinnumbox.setBounds(220,315,125,20);
        pinnumbox.addActionListener(this);
        image.add(pinnumbox);
        newpinnum = new JLabel("New PIN:-");
        newpinnum.setBounds(130,350,100,20);
        newpinnum.setFont(new Font("Raleway",Font.BOLD,16));
        newpinnum.setForeground(Color.white);
        image.add(newpinnum);
        newpinnumbox = new JPasswordField("");
        newpinnumbox.setBounds(220,350,125,20);
        newpinnumbox.addActionListener(this);
        image.add(newpinnumbox);
        setpin = new JButton("Set New PIN");
        setpin.setBounds(270,390,120,25);
        setpin.setFont(new Font("Raleway",Font.BOLD,14));
        setpin.setBackground(Color.white);
        setpin.setForeground(Color.black);
        setpin.addActionListener(this);
        image.add(setpin);
        clear = new JButton("Clear");
        clear.setBounds(130,390,100,25);
        clear.setFont(new Font("Raleway",Font.BOLD,16));
        clear.setBackground(Color.white);
        clear.setForeground(Color.black);
        clear.addActionListener(this);
        image.add(clear);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==setpin){
            String newpinbox = newpinnumbox.getText();
            String oldpinbox = pinnumbox.getText();
            if(newpinbox.equals(oldpinbox)){
                JOptionPane.showMessageDialog(null,"Enter Different from Last PIN");
                newpinnumbox.setText(null);
                pinnumbox.setText(null);
                return;
            }
            else if(newpinbox.equals("")){
                JOptionPane.showMessageDialog(null,"Please Enter New Pin");
                return;
            }
            else if(oldpinbox.equals("")){
                JOptionPane.showMessageDialog(null,"Please Enter Old PIN");
                return;
            }
            try{
                Conn conn = new Conn();
                String query1 = "update bank set PIN_Number = '"+newpinbox+"' where PIN_Number = '"+oldpinbox+"'";
                String query2 = "update login set PIN_Number = '"+newpinbox+"' where PIN_Number = '"+oldpinbox+"'";
                String query3 = "update signupThree set PIN_Number = '"+newpinbox+"' where PIN_Number = '"+oldpinbox+"'";
                conn.s.executeUpdate(query1);
                conn.s.executeUpdate(query2);
                conn.s.executeUpdate(query3);

                JOptionPane.showMessageDialog(null,"PIN changed Successfully");
                setVisible(false);
                new Transactions(newpinbox).setVisible(true);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        if(ae.getSource()==clear){
            cardnumbox.setText(null);
            pinnumbox.setText(null);
            newpinnumbox.setText(null);
        }
    }
    public static void main(String[] args) {
        new ChangePin("");
    }
}
