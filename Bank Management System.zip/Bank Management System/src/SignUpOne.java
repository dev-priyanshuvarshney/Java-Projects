import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import com.toedter.calendar.JDateChooser;

public class SignUpOne extends JFrame implements ActionListener {
    long random;
    JTextField nameTextField, FnameTextField, contactTextField, addrTextField, emailTextField, cityTextField, stateTextField, pincodeTextField;
    JRadioButton male, female;
    JDateChooser dateChooser;
    SignUpOne(){
        setLayout(null);
        setVisible(true);
        setSize(850,800);
        setLocation(350,10);
        setTitle("SIGN-UP Form");
        getContentPane().setBackground(Color.white);
//        Generate Random No.
        Random ran = new Random();
        random = Math.abs(ran.nextLong()%9000L)+1000L;

        JLabel formNo = new JLabel("Application Form " + random);
        formNo.setFont(new Font("Raleway", Font.BOLD, 40));
        formNo.setBounds(220,50,600,40);
        add(formNo);

        JLabel name = new JLabel("Name:");
        name.setBounds(80,140,80,30);
        name.setFont(new Font("Arial", Font.BOLD,26));
        add(name);
        nameTextField = new JTextField();
        nameTextField.setBounds(400,140,400,30);
        add(nameTextField);

        JLabel Fname = new JLabel("Father's Name:");
        Fname.setBounds(80,200,250,30);
        Fname.setFont(new Font("Arial", Font.BOLD,26));
        add(Fname);
        FnameTextField = new JTextField();
        FnameTextField.setBounds(400,200,400,30);
        add(FnameTextField);


        JLabel ContactNo = new JLabel("ContactNo:");
        ContactNo.setBounds(80,260,250,30);
        ContactNo.setFont(new Font("Arial", Font.BOLD,26));
        add(ContactNo);
        contactTextField = new JTextField();
        contactTextField.setBounds(400,260,400,30);
        add(contactTextField);

        JLabel Email = new JLabel("E-mail:");
        Email.setBounds(80,320,250,30);
        Email.setFont(new Font("Arial", Font.BOLD,26));
        add(Email);
        emailTextField = new JTextField();
        emailTextField.setBounds(400,320,400,30);
        add(emailTextField);

        JLabel address = new JLabel("Address:");
        address.setBounds(80,380,250,30);
        address.setFont(new Font("Arial", Font.BOLD,26));
        add(address);
        addrTextField = new JTextField();
        addrTextField.setBounds(400,380,400,30);
        add(addrTextField);

        JLabel Dob = new JLabel("D.O.B:");
        Dob.setBounds(80,440,250,30);
        Dob.setFont(new Font("Arial", Font.BOLD,26));
        add(Dob);
        dateChooser = new JDateChooser();
        dateChooser.setBounds(400,440,400,30);
        add(dateChooser);


        JLabel gender = new JLabel("Gender");
        gender.setBounds(80,500,250,30);
        gender.setFont(new Font("Arial", Font.BOLD,26));
        add(gender);
        male = new JRadioButton("Male");
        male.setBounds(400, 500,80,30);
        male.setFont(new Font("Arial", Font.BOLD, 16));
        male.setBackground(Color.white);
        male.setForeground(Color.black);
        add(male); 
        female = new JRadioButton("Female");
        female.setBounds(550, 500,100,30);
        female.setFont(new Font("Arial", Font.BOLD, 16));
        female.setBackground(Color.white);
        female.setForeground(Color.black);
        add(female);
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(male);
        genderGroup.add(female);

        JLabel city = new JLabel("City:");
        city.setBounds(80,560,250,30);
        city.setFont(new Font("Arial", Font.BOLD,26));
        add(city);
        cityTextField = new JTextField();
        cityTextField.setBounds(400,560,400,30);
        add(cityTextField);

        JLabel state = new JLabel("State:");
        state.setBounds(80,620,250,30);
        state.setFont(new Font("Arial", Font.BOLD,26));
        add(state);
        stateTextField = new JTextField();
        stateTextField.setBounds(400,620,400,30);
        add(stateTextField);

        JLabel pincode = new JLabel("Pin Code:");
        pincode.setBounds(80,680,250,30);
        pincode.setFont(new Font("Arial", Font.BOLD,26));
        add(pincode);
        pincodeTextField = new JTextField();
        pincodeTextField.setBounds(400,680,400,30);
        add(pincodeTextField);

        JButton nextButton = new JButton("Next");
        nextButton.setForeground(Color.white);
        nextButton.setBackground(Color.black);
        nextButton.setFont(new Font("Arial", Font.BOLD, 28));
        nextButton.setBounds(600,740,200,30);
        add(nextButton);
        nextButton.addActionListener(this);
    }
    public void actionPerformed(ActionEvent ae){
        String formNo = ""+random;
        String name = nameTextField.getText();
        String Fname = FnameTextField.getText();
        String Contact = contactTextField.getText();
        String dob = ((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();
        String gender = null;
        if(male.isSelected()){
            gender = "Male";
        }
        else if(female.isSelected()){
            gender = "Female";
        }
        String email = emailTextField.getText();
        String address = addrTextField.getText();
        String city = cityTextField.getText();
        String state = stateTextField.getText();
        String pincode = pincodeTextField.getText();

        try{
            if(name.equals("")){
                JOptionPane.showMessageDialog(null, "Please Enter Your Name:");
            }
            else if(Fname.equals("")){
                JOptionPane.showMessageDialog(null,"Please Enter your Father's Name:");
            }
            else if(Contact.equals("")){
                JOptionPane.showMessageDialog(null,"Please Enter your contact number:");
            }
            else if(dob.equals("")){
                JOptionPane.showMessageDialog(null,"Select your Date of Birth:");
            }
            else if(gender.equals("")){
                JOptionPane.showMessageDialog(null,"Select your Gender:");
            }
            else if(email.equals("")){
                JOptionPane.showMessageDialog(null,"Please Enter your E-mail");
            }
            else if(address.equals("")){
                JOptionPane.showMessageDialog(null,"Please Enter your adddress number");
            }
            else if(city.equals("")){
                JOptionPane.showMessageDialog(null,"Please Enter your City");
            }
            else if(state.equals("")){
                JOptionPane.showMessageDialog(null,"Please Enter your State");
            }
            else if(pincode.equals("")){
                JOptionPane.showMessageDialog(null,"Please Enter your PinCode");
            }
            else {
                Conn c = new Conn();
                String query = "insert into signup values('"+formNo+"','"+name+"', '"+Fname+"', '"+Contact+"', '"+dob+"', '"+gender+"', '"+email+"', '"+address+"', '"+city+"', '"+state+"', '"+pincode+"')";
                c.s.executeUpdate(query);

                setVisible(false);
                new SignUpTwo(formNo).setVisible(true);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public static void main(String[] args) {
        new SignUpOne();
    }
}
