import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Transactions extends JFrame implements ActionListener {
    JButton deposit,withdraw,fastcash,ministatement,pinchange,balanceenquiry,exit;
    JLabel image,text;
    String pinnum;
    Transactions(String pinnum){
        this.pinnum=pinnum;
        setSize(700,700);
//        setUndecorated(true);
        setLayout(null);
        setLocation(350,20);
        setTitle("Transaction Page");
        setVisible(true);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(700,700,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        image = new JLabel(i3);
        image.setBounds(0,0,700,700);
        add(image);

        text = new JLabel("Please Make Your Transactions");
        text.setBounds(175,210,250,50);
        text.setFont(new Font("System",Font.PLAIN,12));
        text.setForeground(Color.white);
        image.add(text);

        deposit = new JButton("Deposit");
        deposit.setBounds(125,324,100,20);
        deposit.setFont(new Font("Raleway",Font.BOLD,12));
        deposit.setBackground(Color.white);
        deposit.setForeground(Color.BLACK);
        deposit.addActionListener(this);
        image.add(deposit);
        withdraw = new JButton("Cash Withdraw");
        withdraw.setBounds(278,324,120,20);
        withdraw.setFont(new Font("Raleway",Font.BOLD,12));
        withdraw.setBackground(Color.white);
        withdraw.setForeground(Color.BLACK);
        withdraw.addActionListener(this);
        image.add(withdraw);
        fastcash = new JButton("Fast Cash");
        fastcash.setBounds(125,350,100,20);
        fastcash.setFont(new Font("Raleway",Font.BOLD,12));
        fastcash.setBackground(Color.white);
        fastcash.setForeground(Color.BLACK);
        fastcash.addActionListener(this);
        image.add(fastcash);
        ministatement = new JButton("Mini Statement");
        ministatement.setBounds(278,350,120,20);
        ministatement.setFont(new Font("Raleway",Font.BOLD,12));
        ministatement.setBackground(Color.white);
        ministatement.setForeground(Color.BLACK);
        ministatement.addActionListener(this);
        image.add(ministatement);
        pinchange = new JButton("Change PIN");
        pinchange.setBounds(125,377,100,20);
        pinchange.setFont(new Font("Raleway",Font.BOLD,11));
        pinchange.setBackground(Color.white);
        pinchange.setForeground(Color.BLACK);
        pinchange.addActionListener(this);
        image.add(pinchange);
        balanceenquiry = new JButton("Balance Enquiry");
        balanceenquiry.setBounds(278,377,120,20);
        balanceenquiry.setFont(new Font("Raleway",Font.BOLD,10));
        balanceenquiry.setBackground(Color.white);
        balanceenquiry.setForeground(Color.BLACK);
        balanceenquiry.addActionListener(this);
        image.add(balanceenquiry);
        exit = new JButton("Exit");
        exit.setBounds(320,410,80,15);
        exit.setFont(new Font("Raleway",Font.BOLD,12));
        exit.setBackground(Color.red);
        exit.setForeground(Color.white);
        exit.addActionListener(this);
        image.add(exit);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==exit){
            System.exit(0);
        }
        if(ae.getSource()==deposit){
            setVisible(false);
            new Deposit(pinnum).setVisible(true);
        }
        if(ae.getSource()==withdraw){
            setVisible(false);
            new Withdraw(pinnum).setVisible(true);
        }
        if(ae.getSource()==fastcash){
            setVisible(false);
            new Fastcash(pinnum).setVisible(true);
        }
        if(ae.getSource()==pinchange){
            setVisible(false);
            new ChangePin(pinnum).setVisible(true);
        }
        if(ae.getSource()==balanceenquiry){
            setVisible(false);
            new BalanceEnquiry(pinnum).setVisible(true);
        }
        if(ae.getSource()==ministatement){
            setVisible(false);
            new Ministatement(pinnum).setVisible(true);
        }
    }
    public static void main(String[] args) {
        new Transactions("");
    }
}
