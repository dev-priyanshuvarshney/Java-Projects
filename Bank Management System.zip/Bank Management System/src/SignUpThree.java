import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLOutput;
import java.util.Random;

public class SignUpThree extends JFrame implements ActionListener {
    JLabel text,account,cardnum,cardnum2,pin,pin2,services,cnum,pnum;
    JRadioButton saving, current, fixed, recurring;
    JCheckBox atm,internet, mobile, sms, cheque, statement, declare;
    JButton submit, cancel;
    String formNo;
    SignUpThree(String formNo){
        this.formNo=formNo;
        setLayout(null);
        setLocation(400,50);
        setVisible(true);
        setSize(680,750);
        setTitle("SIGN-UP FORM");
        getContentPane().setBackground(Color.white);

        text = new JLabel("Page No.-3");
        text.setBounds(240,20,200,60);
        text.setFont(new Font("Raleway",Font.BOLD, 38));
        add(text);

        account = new JLabel("Account Type:");
        account.setBounds(50,120,200,30);
        account.setFont(new Font("Arial",Font.BOLD,26));
        add(account);

        saving = new JRadioButton("Saving Account");
        saving.setBounds(80,155,150,30);
        saving.setFont(new Font("Arial", Font.PLAIN,14));
        saving.setBackground(Color.white);
        saving.setForeground(Color.black);
        add(saving);
        current = new JRadioButton("Current Account");
        current.setBounds(80,180,150,30);
        current.setFont(new Font("Arial", Font.PLAIN,14));
        current.setBackground(Color.white);
        current.setForeground(Color.black);
        add(current);
        fixed = new JRadioButton("Fixed Deposit Account");
        fixed.setBounds(350,155,350,30);
        fixed.setFont(new Font("Arial", Font.PLAIN,14));
        fixed.setBackground(Color.white);
        fixed.setForeground(Color.black);
        add(fixed);
        recurring = new JRadioButton("Recurring Fixed Account");
        recurring.setBounds(350,180,350,30);
        recurring.setFont(new Font("Arial", Font.PLAIN,14));
        recurring.setBackground(Color.white);
        recurring.setForeground(Color.black);
        add(recurring);
        ButtonGroup typeGroup = new ButtonGroup();
        typeGroup.add(saving);
        typeGroup.add(current);
        typeGroup.add(fixed);
        typeGroup.add(recurring);

        cardnum = new JLabel("Card Number:");
        cardnum.setFont(new Font("Arial",Font.BOLD,26));
        cardnum.setBounds(50,230,200,30);
        add(cardnum);
        cnum = new JLabel("XXXX XXXX XXXX 2005");
        cnum.setFont(new Font("Raleway", Font.BOLD,24));
        cnum.setBounds(300,225,350,50);
        add(cnum);
        cardnum2 = new JLabel("Your 14 Digit Card Number is");
        cardnum2.setBounds(50,250,300,30);
        cardnum2.setFont(new Font("Raleway", Font.ITALIC,12));
        add(cardnum2);

        pin = new JLabel("PIN:");
        pin.setBounds(50,300,150,30);
        pin.setFont(new Font("Arial",Font.BOLD,26));
        add(pin);
        pnum = new JLabel("XXXX");
        pnum.setFont(new Font("Raleway", Font.BOLD,24));
        pnum.setBounds(300,295,150,50);
        add(pnum);
        pin2 = new JLabel("Your 4 Digit PIN Number is");
        pin2.setBounds(50,320,300,30);
        pin2.setFont(new Font("Raleway", Font.ITALIC,12));
        add(pin2);

        services = new JLabel("Services Required:");
        services.setFont(new Font("Arial",Font.BOLD,26));
        services.setBounds(50,370,350,30);
        add(services);

        atm = new JCheckBox("ATM Card");
        atm.setBounds(80,410,150,30);
        atm.setFont(new Font("Arial",Font.PLAIN,14));
        atm.setBackground(Color.white);
        atm.setForeground(Color.black);
        add(atm);
        internet = new JCheckBox("Internet Banking");
        internet.setBounds(350,410,150,30);
        internet.setFont(new Font("Arial",Font.PLAIN,14));
        internet.setBackground(Color.white);
        internet.setForeground(Color.black);
        add(internet);
        mobile = new JCheckBox("Mobile Banking");
        mobile.setBounds(80,445,150,30);
        mobile.setFont(new Font("Arial",Font.PLAIN,14));
        mobile.setBackground(Color.white);
        mobile.setForeground(Color.black);
        add(mobile);
        sms = new JCheckBox("E-Mails & SMS Alerts");
        sms.setBounds(350,445,250,30);
        sms.setFont(new Font("Arial",Font.PLAIN,14));
        sms.setBackground(Color.white);
        sms.setForeground(Color.black);
        add(sms);
        cheque = new JCheckBox("Cheque Book");
        cheque.setBounds(80,480,150,30);
        cheque.setFont(new Font("Arial",Font.PLAIN,14));
        cheque.setBackground(Color.white);
        cheque.setForeground(Color.black);
        add(cheque);
        statement = new JCheckBox("E-Statement");
        statement.setBounds(350,480,150,30);
        statement.setFont(new Font("Arial",Font.PLAIN,14));
        statement.setBackground(Color.white);
        statement.setForeground(Color.black);
        add(statement);


        declare = new JCheckBox("I hereby Declare that my all Details are True");
        declare.setBounds(50,550,450,30);
        declare.setFont(new Font("Arial",Font.BOLD,14));
        declare.setBackground(Color.white);
        declare.setForeground(Color.black);
        add(declare);

        submit = new JButton("Submit");
        submit.setBounds(100,610,150,50);
        submit.setFont(new Font("Raleway",Font.BOLD,28));
        submit.setBackground(Color.black);
        submit.setForeground(Color.white);
        submit.addActionListener(this);
        add(submit);
        cancel = new JButton("Cancel");
        cancel.setBounds(400,610,150,50);
        cancel.setFont(new Font("Raleway",Font.BOLD,28));
        cancel.setBackground(Color.black);
        cancel.setForeground(Color.white);
        cancel.addActionListener(this);
        add(cancel);
    }
    public void actionPerformed(ActionEvent ae){
        String type = null;
        if(saving.isSelected()){
            type = "Saving Account";
        }
        else if(current.isSelected()){
            type = "Current Account";
        }
        else if(fixed.isSelected()){
            type = "Fixed Deposit Account";
        }
        else if(recurring.isSelected()){
            type = "Recurring Fixed Account";
        }

        Random ran = new Random();
        String cardnumber = String.valueOf(Math.abs((ran.nextLong() % 90000000L)) + 5040636000000000L);

        String pinnumber = "" + Math.abs((ran.nextLong() % 9000L)+1000L);

        String servicesrequired = "";
        if(atm.isSelected()){
            servicesrequired = servicesrequired + " ATM Card";
        } else if(internet.isSelected()){
            servicesrequired = servicesrequired + " Internet Banking";
        } else if(mobile.isSelected()){
            servicesrequired = servicesrequired + " Mobile Banking";
        } else if (sms.isSelected()) {
            servicesrequired = servicesrequired + " E-Mails & SMS Alerts";
        } else if (cheque.isSelected()) {
            servicesrequired = servicesrequired + " Cheque Book";
        } else if (statement.isSelected()) {
            servicesrequired = servicesrequired + " E-Statement";
        }
        if(ae.getSource() == submit){
            JOptionPane.showMessageDialog(null,"Card Number "+cardnumber + "\n PIN Number " + pinnumber);
        }
        else if(ae.getSource() == cancel){
            if(ae.getSource()==cancel){
                System.exit(0);
            }
        }
        try{
            if(type.equals("")){
                JOptionPane.showMessageDialog(null, "Please Select Your Account Type");
            }
            else{
                Conn conn = new Conn();
                String query1 = "insert into signupThree values('"+formNo+"', '"+type+"', '"+cardnumber+"', '"+pinnumber+"', '"+servicesrequired+"')";
                String query2 = "insert into login values('"+formNo+"', '"+cardnumber+"', '"+pinnumber+"')";

                conn.s.executeUpdate(query1);
                conn.s.executeUpdate(query2);
                setVisible(false);
                new Login(formNo).setVisible(true);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public static void main(String[] args) {
        new SignUpThree("");
    }
}
