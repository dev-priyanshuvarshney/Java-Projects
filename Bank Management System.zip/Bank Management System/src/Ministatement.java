import javax.swing.*;
import java.sql.ResultSet;

public class Ministatement extends JFrame {
    Ministatement(String pinnum){
        setSize(400,500);
        setLayout(null);
        setLocation(350,50);
        setTitle("Mini-Reciept");
        setVisible(true);

        JLabel text = new JLabel();
        text.setBounds(30,100,400,30);
        add(text);

        JLabel mini = new JLabel();
        mini.setBounds(30,150,400,30);
        add(mini);
        try{
            Conn conn = new Conn();
            ResultSet rs = conn.s.executeQuery("select * from login where PIN_Number = '"+pinnum+"'");
            while (rs.next()){
                text.setText("Card Number: "+rs.getString("Card_Number").substring(0,4)+"XXXXXXXX"+rs.getString("Card_Number").substring(12));
            }
        } catch (Exception e){
            System.out.println(e);
        }
        try{
            Conn conn = new Conn();
            ResultSet rs = conn.s.executeQuery("select * from bank where PIN_Number = '"+pinnum+"'");
            while (rs.next()){
                mini.setText(mini.getText()+ "<html>"+rs.getString("Date") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs.getString("Type") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs.getString("Amount"));
            }
        } catch(Exception e){
            System.out.println(e);
        }

    }
    public static void main(String[] args) {
        new Ministatement("");
    }
}
