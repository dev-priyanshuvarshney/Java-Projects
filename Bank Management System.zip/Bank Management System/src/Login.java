import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Login extends JFrame implements ActionListener {
    JButton loginButton, signUpButton, clearButton;
    JTextField cardTextField;
    JPasswordField pinTextField;
    String formNo;
        Login(String formNo){
            setLayout(null);
            setSize(800,500);
            setLocation(350,200);
            setVisible(true);
            setTitle("ATM Machine");
            ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/logo.jpg"));
            Image i2 = i1.getImage().getScaledInstance(100,100, Image.SCALE_DEFAULT);
            ImageIcon i3 = new ImageIcon(i2);
            JLabel label = new JLabel(i3);
            label.setBounds(70,10,100,100);
            add(label);
            getContentPane().setBackground(Color.WHITE);

            JLabel text = new JLabel("Welcome to ATM");
            add(text);
            text.setBounds(200,40,400,40);
            text.setFont(new Font("Osward", Font.BOLD, 38));

            JLabel cardNo = new JLabel("Card No.");
            add(cardNo);
            cardNo.setBounds(120,150,400,40);
            cardNo.setFont(new Font("Raleway", Font.BOLD, 28));
            cardTextField = new JTextField();
            cardTextField.setBounds(300,150,320,40);
            cardTextField.setFont(new Font("Arial", Font.BOLD,20));
            add(cardTextField);

            JLabel pin = new JLabel("PIN:");
            add(pin);
            pin.setBounds(120,220,400,50);
            pin.setFont(new Font("Raleway", Font.BOLD, 28));
            pinTextField = new JPasswordField();
            pinTextField.setBounds(300,230,320,40);
            pinTextField.setFont(new Font("Arial", Font.BOLD,20));
            add(pinTextField);

            loginButton = new JButton("LOGIN");
            add(loginButton);
            loginButton.setFont(new Font("Raleway",Font.BOLD, 20));
            loginButton.setForeground(Color.white);
            loginButton.setBackground(Color.BLACK);
            loginButton.addActionListener(this);
            loginButton.setBounds(300, 300,100,50);

            clearButton = new JButton("CLEAR");
            add(clearButton);
            clearButton.setFont(new Font("Raleway",Font.BOLD, 20));
            clearButton.setForeground(Color.white);
            clearButton.setBackground(Color.BLACK);
            clearButton.addActionListener(this);
            clearButton.setBounds(500, 300,120,50);

            signUpButton = new JButton("SIGN UP");
            add(signUpButton);
            signUpButton.setFont(new Font("Raleway",Font.BOLD, 20));
            signUpButton.setForeground(Color.white);
            signUpButton.setBackground(Color.BLACK);
            signUpButton.addActionListener(this);
            signUpButton.setBounds(390, 380,120,50);
        }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == clearButton){
            cardTextField.setText(null);
            pinTextField.setText(null);
        }
        else if(ae.getSource() == loginButton){
            Conn conn = new Conn();
            String cardnum = cardTextField.getText();
            String pinnum = pinTextField.getText();
            String query = "Select * from login where Card_Number = '"+cardnum+"' and PIN_Number = '"+pinnum+"'";
            try{
                ResultSet rs = conn.s.executeQuery(query);
                if(rs.next()){
                    setVisible(false);
                    new Transactions(pinnum).setVisible(true);
                }
                else {
                    JOptionPane.showMessageDialog(null,"Incorrect CardNumber and PIN Number");
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        else if(ae.getSource() == signUpButton){
            setVisible(false);
            new SignUpOne().setVisible(true);
        }
    }

    public static void main(String[] args) {
        new Login("");
    }
}
