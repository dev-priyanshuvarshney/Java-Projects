import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.sql.ResultSet;

public class Fastcash extends JFrame implements ActionListener {
    JButton cash200,cash500,cash1000,cash2000,cash5K,cash10K,exit;
    String pinnum;
    Fastcash(String pinnum){
        this.pinnum=pinnum;
        setSize(700,700);
        setVisible(true);
        setLayout(null);
        setLocation(400,50);
        setTitle("FastCash");
        getContentPane().setBackground(Color.WHITE);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(700,700,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0,700,700);
        add(image);

        cash200 = new JButton("Rs 200");
        cash200.setBounds(125,324,100,20);
        cash200.setFont(new Font("Raleway",Font.BOLD,12));
        cash200.setBackground(Color.white);
        cash200.setForeground(Color.BLACK);
        cash200.addActionListener(this);
        image.add(cash200);
        cash500 = new JButton("Rs 500");
        cash500.setBounds(278,324,120,20);
        cash500.setFont(new Font("Raleway",Font.BOLD,12));
        cash500.setBackground(Color.white);
        cash500.setForeground(Color.BLACK);
        cash500.addActionListener(this);
        image.add(cash500);
        cash1000 = new JButton("Rs 1000");
        cash1000.setBounds(125,350,100,20);
        cash1000.setFont(new Font("Raleway",Font.BOLD,12));
        cash1000.setBackground(Color.white);
        cash1000.setForeground(Color.BLACK);
        cash1000.addActionListener(this);
        image.add(cash1000);
        cash2000 = new JButton("Rs 2000");
        cash2000.setBounds(278,350,120,20);
        cash2000.setFont(new Font("Raleway",Font.BOLD,12));
        cash2000.setBackground(Color.white);
        cash2000.setForeground(Color.BLACK);
        cash2000.addActionListener(this);
        image.add(cash2000);
        cash5K = new JButton("Rs 5000");
        cash5K.setBounds(125,377,100,20);
        cash5K.setFont(new Font("Raleway",Font.BOLD,12));
        cash5K.setBackground(Color.white);
        cash5K.setForeground(Color.BLACK);
        cash5K.addActionListener(this);
        image.add(cash5K);
        cash10K = new JButton("Rs 10000");
        cash10K.setBounds(278,377,120,20);
        cash10K.setFont(new Font("Raleway",Font.BOLD,12));
        cash10K.setBackground(Color.white);
        cash10K.setForeground(Color.BLACK);
        cash10K.addActionListener(this);
        image.add(cash10K);
        exit = new JButton("Exit");
        exit.setBounds(320,410,80,15);
        exit.setFont(new Font("Raleway",Font.BOLD,12));
        exit.setBackground(Color.red);
        exit.setForeground(Color.white);
        exit.addActionListener(this);
        image.add(exit);
    }

    public void actionPerformed(ActionEvent ae){
        if (ae.getSource()==exit){
            setVisible(false);
            new Transactions(pinnum).setVisible(true);
        }
        else{
            String amount = ((JButton)ae.getSource()).getText().substring(3);
            Conn conn = new Conn();
            try {
                ResultSet rs = conn.s.executeQuery("select * from bank where PIN_Number = '"+pinnum+"'");
                int balance = 0;
                while(rs.next()){
                    if (rs.getString("Type").equals("Deposit")){
                        balance += Integer.parseInt(rs.getString("Amount"));
                    }
                    else{
                        balance -= Integer.parseInt(rs.getString("Amount"));
                    }
                }
                if(ae.getSource() != exit && balance<Integer.parseInt(amount)){
                    JOptionPane.showMessageDialog(null,"Insufficient Balance");
                    return;
                }
                Date date = new Date();
                String query = "insert into bank values('"+pinnum+"', '"+date+"', 'Withdraw' , '"+amount+"')";
                conn.s.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Rs. "+amount+" Debited Successfully");
                setVisible(false);
                new Transactions(pinnum).setVisible(true);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }
    public static void main(String[] args) {
        new Fastcash("");
    }
}
