import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Server implements ActionListener {
    JTextField text;
    JPanel p1, p2;
    JButton send;
    static Box vertical = Box.createVerticalBox();
    static JFrame f = new JFrame();
    static DataOutputStream dout;

    Server(){
        f.setSize(500,600);
        f.setLayout(null);
        f.setLocation(250,50);
        f.getContentPane().setBackground(Color.WHITE);
        f.setUndecorated(true);
        f.setVisible(true);

        p1 = new JPanel();
        p1.setBackground(new Color(7,91,84));
        p1.setBounds(0,0,500,70);
        p1.setLayout(null);
        f.add(p1);

        ImageIcon arrow = new ImageIcon(ClassLoader.getSystemResource("Icons/image3.png"));
        Image arrow1 = arrow.getImage().getScaledInstance(30,25,Image.SCALE_DEFAULT);
        ImageIcon arrow2 = new ImageIcon(arrow1);
        JLabel arrow3 = new JLabel(arrow2);
        arrow3.setBounds(5,20,30,25);
        p1.add(arrow3);

        ImageIcon profile = new ImageIcon(ClassLoader.getSystemResource("Icons/image1.png"));
        Image profile1 = profile.getImage().getScaledInstance(50,50,Image.SCALE_DEFAULT);
        ImageIcon profile2 = new ImageIcon(profile1);
        JLabel image = new JLabel(profile2);
        image.setBounds(50,10,50,50);
        p1.add(image);

        ImageIcon video = new ImageIcon(ClassLoader.getSystemResource("Icons/video.png"));
        Image video1 = video.getImage().getScaledInstance(30,30,Image.SCALE_DEFAULT);
        ImageIcon video2 = new ImageIcon(video1);
        JLabel video3 = new JLabel(video2);
        video3.setBounds(350,20,30,30);
        p1.add(video3);

        ImageIcon phone = new ImageIcon(ClassLoader.getSystemResource("Icons/phone.png"));
        Image phone1 = phone.getImage().getScaledInstance(30,30,Image.SCALE_DEFAULT);
        ImageIcon phone2 = new ImageIcon(phone1);
        JLabel phone3 = new JLabel(phone2);
        phone3.setBounds(400,21,30,30);
        p1.add(phone3);

        ImageIcon bindi = new ImageIcon(ClassLoader.getSystemResource("Icons/3icon.png"));
        Image bindi1 = bindi.getImage().getScaledInstance(10,25,Image.SCALE_DEFAULT);
        ImageIcon bindi2 = new ImageIcon(bindi1);
        JLabel bindi3 = new JLabel(bindi2);
        bindi3.setBounds(450,22,10,25);
        p1.add(bindi3);

        JLabel name = new JLabel("Gaitonde");
        name.setBounds(110,20,150,30);
        name.setFont(new Font("San_Serif",Font.BOLD,24));
        name.setForeground(Color.white);
        p1.add(name);

        JLabel status = new JLabel("Active Now");
        status.setBounds(115,40,150,30);
        status.setFont(new Font("San_Serif",Font.BOLD,14));
        status.setForeground(Color.white);
        p1.add(status);

        p2 = new JPanel();
        p2.setBounds(10,70,480,480);
        f.add(p2);

        text = new JTextField("Type Your Message");
        text.setBounds(10,550,370,40);
        text.setFont(new Font("San_Serif",Font.PLAIN,18));
        text.addActionListener(this);
        text.setPreferredSize(new Dimension(200,30));
        f.add(text);

        send = new JButton("Send");
        send.setBounds(390,550,100,40);
        send.setFont(new Font("Raleway",Font.BOLD,20));
        send.setBackground(new Color(7,94,84));
        send.setForeground(Color.white);
        send.addActionListener(this);
        f.add(send);

        arrow3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.exit(0);
            }
        });
        text.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if(text.getText().equals("Type Your Message")){
                    text.setText("");
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if(text.getText().isEmpty()){
                    text.setText("Type Your Message");
                }
            }
        });
    }
    public void actionPerformed(ActionEvent ae){
        try {
            String out = text.getText();

            p2.setLayout(new BorderLayout());

            JPanel a1 = formatLabel(out);
            JPanel right = new JPanel(new BorderLayout());
            right.add(a1, BorderLayout.LINE_END);
            vertical.add(right);
            vertical.add(Box.createVerticalStrut(15));
            p2.add(vertical, BorderLayout.PAGE_START);
            if (ae.getSource() == send) {
                text.setText("Type Your Message");
            }
            dout.writeUTF(out);
            f.setBackground(Color.white);
            f.repaint();
            f.invalidate();
            f.validate();
        } catch (Exception e){
            System.out.println(e);
        }
    }

    public static JPanel formatLabel(String out){
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel output = new JLabel(out);
        output.setFont(new Font("Tahoma",Font.PLAIN,18));
        panel.add(output);
        output.setBackground(new Color(37,211,102));
        output.setOpaque(true);
        output.setBorder(new EmptyBorder(15,15,15,50));

        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");

        JLabel time = new JLabel();
        time.setText(sdf.format(cal.getTime()));
        panel.add(time);
        return panel;
    }
    public static void main(String[] args) {
        new Server();

        try{
            ServerSocket skt = new ServerSocket(6001);
            while(true){
                Socket s = skt.accept();
                DataInputStream din = new DataInputStream(s.getInputStream());
                dout = new DataOutputStream(s.getOutputStream());

                while (true){
                    String msg = din.readUTF();
                    JPanel panel = formatLabel(msg);

                    JPanel left = new JPanel(new BorderLayout());
                    left.add(panel,BorderLayout.LINE_START);
                    vertical.add(left);
                    f.validate();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
